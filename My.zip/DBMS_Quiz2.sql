/* Task 1 */
CREATE DATABASE IF NOT EXISTS worldcountries;
USE worldcountries

/* Task 2 */
CREATE TABLE IF NOT EXISTS countries (
    country_code VARCHAR(20) PRIMARY KEY,
    country_name VARCHAR(20) NOT NULL,
    continent_id INT(20),

    CONSTRAINT fk_continent_id
    FOREIGN KEY (continent_id)
        REFERENCES continents(continent_id)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS cities (
    `city_id` INT AUTO_INCREMENT PRIMARY KEY,
    `city_name` VARCHAR(50) NOT NULL,
    `country_code` VARCHAR(20),
    `population` INT NOT NULL,
    `year` INT(4),
    `capital` BOOLEAN DEFAULT(FALSE),

    CONSTRAINT fk_country_code
    FOREIGN KEY (country_code)
        REFERENCES countries(country_code)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS continents (
    continent_id INT AUTO_INCREMENT PRIMARY KEY,
    continent_name VARCHAR(50) NOT NULL
);


/* Task 3 */
UPDATE continents
SET continent_id = 6
WHERE continent_id = 100;

DELETE FROM countries
WHERE country_code = "RU";

SELECT * FROM cities;


/* Task 4 */
INSERT INTO continents(continent_name)
VALUES
    ("Europe"),
    ("Asia"),
    ("Africa"),
    ("America"),
    ("Australia"),
    ("Antarctida");


/* Task 5 */
INSERT INTO countries(country_code, country_name, continent_id)
VALUES
    ("TR", "Turkey", 1),
    ("AZ", "Azerbaijan", 2),
    ("RU", "Russia", 1),
    ("AU", "Australia", 5),
    ("SW", "Sweden", 1),
    ("IR", "Iran", 2),
    ("FR", "France", 1),
    ("SP", "Spain", 2),
    ("ARG", "Argentina", 4),
    ("BR", "Brasil", 4),
    ("VE", "Venesuela", 4),
    ("JP", "Japan", 2),
    ("CO", "Congo", 3),
    ("NG", "Nigeria", 3),
    ("KO", "Korea", 2);


/* Task 6 */
INSERT INTO cities(`city_name`, `country_code`, `population`, `year`, `capital`)
VALUES
    ("Istanbul", "TR", 100000, 1800, 0),
    ("Baku", "AZ", 3000000, 1975, 0),
    ("Moscow", "RU", 4000000, 1050, 1),
    ("Melbrun", "AU", 5000000, 300, 0),
    ("Malmo", "SW", 7000000, 1500, 0),
    ("Tehran", "IR", 50000, 1902, 1),
    ("Paris", "FR", 500000, 1450, 1),
    ("Barcelona", "SP", 400000, 1400, 0),
    ("Karakas", "VE", 900000, 1800, 1),
    ("Buenos Aires", "ARG", 170000, 1870, 1),
    ("Rio", "BR", 900000, 1700, 0),
    ("Tokio", "JP", 8000000, 1900, 1),
    ("Bukavu", "CO", 80000, 1600, 0),
    ("Abuca", "NG", 100000, 1500, 0),
    ("Seul", "KO", 9154000, 1940, 1);


/* Task 7 */
SELECT continents.`continent_name`,
GROUP_CONCAT(countries.`country_name`, ', ') AS `countries`
FROM continents, countries
WHERE continents.`continent_id` = countries.`continent_id`
GROUP BY continents.`continent_name`; 
    

/* Task 8 */
SELECT countries.`country_name`, cities.`city_name` AS capital_city
FROM countries
LEFT JOIN cities
ON cities.`country_code` = countries.`country_code`
WHERE cities.`capital` = 1;


/* Task 9 */
/* Method 1 */
SELECT continents.`continent_name`, 
GROUP_CONCAT(cities.`city_name`, ', ') AS `cities`,
SUM(cities.`population`) AS total_population
FROM continents, cities, countries
WHERE continents.`continent_id` = countries.`continent_id`
AND countries.`country_code` = cities.`country_code` 
GROUP BY continents.`continent_name`;

/* Method 2 */
SELECT continents.`continent_name`,
GROUP_CONCAT(cities.`city_name`, ', ') AS `cities`,
SUM(cities.`population`) AS total_population
FROM continents
INNER JOIN countries 
ON countries.`continent_id` = continents.`continent_id`
INNER JOIN cities
ON cities.`country_code` = countries.`country_code`
GROUP BY continents.`continent_name`;


/* Task 10 */
SELECT countries.`country_name`, cities.`city_name`, cities.`year`,
CASE
    WHEN ( cities.`year` <= 1000 ) THEN 'ANCIENT'
    WHEN ( cities.`year` > 1000 AND cities.`year` <= 1900 ) THEN 'OLD'
    ELSE 'MODERN'
END
AS age
FROM countries
INNER JOIN cities
ON countries.`country_code` = cities.`country_code`;
    

/* Task 11 */
SELECT countries.`country_name`, countries.`country_code`, 
GROUP_CONCAT(cities.`city_name`, ', ') AS `cities`,
IF (cities.`capital` = 1, cities.`city_name`, NULL) AS `capital_city`, 
COUNT(cities.`capital`) AS count_of_cities,
SUM(cities.`population`) AS total_population_of_cities
FROM countries
LEFT JOIN cities
ON countries.`country_code` = cities.`country_code`
GROUP BY countries.`country_name`;


/* Task 12 */
SELECT countries.`country_name`, 
GROUP_CONCAT(cities.`city_name`, ', ', cities.`year`) AS cities_and_year
FROM countries
INNER JOIN cities
ON countries.`country_code` = cities.`country_code`
AND cities.`population` > (SELECT AVG(`population`) FROM cities)
GROUP BY countries.`country_name`;