DROP DATABASE IF EXISTS dbmsLastQuiz;
CREATE DATABASE dbmsLastQuiz;
USE dbmsLastQuiz;

CREATE TABLE IF NOT EXISTS suppliers(
    supplierID INT UNSIGNED PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(30) NOT NULL DEFAULT '',
    phone CHAR(8) NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS products(
    productID INT UNSIGNED PRIMARY KEY NOT NULL AUTO_INCREMENT,
    productCode VARCHAR(30) NOT NULL DEFAULT '',
    `name` VARCHAR(30) NOT NULL DEFAULT '',
    supplierID INT UNSIGNED NOT NULL,
    quantity INT UNSIGNED NOT NULL DEFAULT 0,
    price DECIMAL(7,2) NOT NULL DEFAULT 99999.99,

    CONSTRAINT fk_supplierID
    FOREIGN KEY (supplierID)
    REFERENCES suppliers(supplierID)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

INSERT INTO suppliers VALUES
    (1, 'ABC Traders', '88881111'),
    (2, 'OYAL', '99442222'),
    (3, 'MR FIX', '90055333'),
    (4, 'Coloritm', '99455333');

INSERT INTO products(productCode, `name`, supplierID, quantity, price)
VALUES
    ('PEC', 'Pencil 2B', 1, 10000, 0.48),
    ('PEC', 'Pencil 2H', 1, 8000, 0.49),
    ('PEC', 'Pencil Color Set N50', 3, 1000, 25.50),
    ('PEC', 'Pencil Color Set N25', 1, 1100, 20.50),
    ('PEC', 'Pencil Color Set N10', 1, 700, 10.00),
    ('PEN', 'Pen Red', 1, 12000, 1.20),
    ('PEN', 'Pen Blue', 2, 12500, 1.15),
    ('PEN', 'Pen Black', 2, 13000, 1.00),
    ('PPR', 'A4', 4, 500, 4.50),
    ('PPR', 'A5', 4, 800, 5.50),
    ('PPR', 'A3', 2, 740, 8.00),
    ('PPR', 'A2', 2, 250, 10.00),
    ('BLK', 'Blackboard 2 x 1.5', 2, 210, 20.00),
    ('BLK', 'Blackboard 1 x 0.5', 3, 200, 12.00),
    ('BLK', 'Blackboard 0.5 x 0.2', 2, 400, 6.00);


-- Task 1
DROP PROCEDURE IF EXISTS getTotalSumOfQuantities;
DELIMITER //
CREATE PROCEDURE getTotalSumOfQuantities(
    IN product_code CHAR(3),
    OUT total INT
)
BEGIN
    SELECT SUM(products.quantity) 
    INTO total
    FROM products
    WHERE productCode = product_code
    GROUP BY productCode;

    SELECT productCode, total AS total 
    FROM products
    WHERE productCode = product_code
    GROUP BY productCode;
END //
DELIMITER ;

CALL getTotalSumOfQuantities('PEC', @total);
CALL getTotalSumOfQuantities('PEN', @total);
CALL getTotalSumOfQuantities('PPR', @total);
CALL getTotalSumOfQuantities('BLK', @total);


-- Task 2
DROP PROCEDURE IF EXISTS getProductsBySuppliers;
DELIMITER //
CREATE PROCEDURE getProductsBySuppliers(
    IN supplier_name VARCHAR(30),
    OUT productCount INT,
    OUT total_quantity INT UNSIGNED
)
BEGIN 
    SELECT COUNT(products.`name`) AS productCount, SUM(products.quantity) AS total_quantity
    INTO productCount, total_quantity
    FROM products
    INNER JOIN suppliers
        ON suppliers.supplierID = products.supplierID
        WHERE suppliers.`name` = supplier_name
    GROUP BY suppliers.`name`;

    SELECT suppliers.supplierID, suppliers.`name`, productCount, total_quantity
    FROM suppliers
    WHERE suppliers.`name` = supplier_name
    GROUP BY suppliers.`name`;
END //
DELIMITER ;

CALL getProductsBySuppliers('ABC Traders', @productCount, @total_quantity);
CALL getProductsBySuppliers('OYAL', @productCount, @total_quantity);
CALL getProductsBySuppliers('MR Fix', @productCount, @total_quantity);
CALL getProductsBySuppliers('Coloritm', @productCount, @total_quantity);


-- Task 3
DROP PROCEDURE IF EXISTS getProducts;
DELIMITER //
CREATE PROCEDURE getProducts(
    IN product_code CHAR(3),
    OUT products VARCHAR(255),
    OUT product_count INT
)
BEGIN
    SELECT GROUP_CONCAT(products.`name` SEPARATOR ', ') AS products, 
    COUNT(products.`name`) AS product_count
    INTO products, product_count
    FROM products
    WHERE productCode = product_code
    GROUP BY productCode;

    SELECT productCode, products, product_count
    FROM products
    WHERE productCode = product_code
    GROUP BY productCode;
END //
DELIMITER ;

CALL getProducts('PEC', @products, @product_count);
CALL getProducts('PEN', @products, @product_count);
CALL getProducts('PPR', @products, @product_count);
CALL getProducts('BLK', @products, @product_count);


-- Task 4
DROP FUNCTION IF EXISTS getIncomeLevel;
DELIMITER //
CREATE FUNCTION getIncomeLevel(
    product_quantity INT,
    product_price FLOAT
)
RETURNS VARCHAR(30)
DETERMINISTIC
BEGIN
    DECLARE income_level VARCHAR(30);

    IF ((product_price * product_quantity) < (SELECT AVG(quantity * price) FROM products)) THEN
        SET income_level = 'low income';
    ELSE
        SET income_level = 'high income';
    END IF;

    RETURN income_level;
END //
DELIMITER ;

SELECT `name`, price, quantity, (price * quantity) AS income, 
        getIncomeLevel(price, quantity) AS income_level
FROM products;


-- Task 5
DROP FUNCTION IF EXISTS getProductsCostByPercentage;
DELIMITER //
CREATE FUNCTION getProductsCostByPercentage(
    product_price FLOAT,
    product_quantity INT
)
RETURNS FLOAT
DETERMINISTIC
BEGIN
    DECLARE total_cost FLOAT;
    DECLARE per_product FLOAT;

    SET total_cost = (SELECT SUM(price * quantity) FROM products);
    SET per_product = ((product_price * product_quantity) / total_cost) * 100;

    RETURN per_product;
END //
DELIMITER ;

SELECT `name`, price, quantity, (price * quantity) AS cost,
        getProductsCostByPercentage(price, quantity) AS percentage
FROM products;


-- Task 6
DROP TABLE IF EXISTS deletedProducts;

CREATE TABLE deletedProducts(
    deleted_productID INT UNSIGNED PRIMARY KEY NOT NULL AUTO_INCREMENT,
    deleted_productCode CHAR(3) NOT NULL DEFAULT '',
    deleted_name VARCHAR(30) NOT NULL DEFAULT '',
    deleted_supplierID INT UNSIGNED NOT NULL,
    deleted_quantity INT UNSIGNED NOT NULL DEFAULT 0,
    deleted_price DECIMAL(7,2) NOT NULL DEFAULT 99999.99,
    deletedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_supplierID_deleted
    FOREIGN KEY (deleted_supplierID)
    REFERENCES suppliers(supplierID)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

DROP TRIGGER IF EXISTS after_delete;
DELIMITER //
CREATE TRIGGER after_delete
AFTER DELETE
ON products FOR EACH ROW
BEGIN
    INSERT INTO deletedProducts (deleted_productID, deleted_productCode, deleted_name, deleted_supplierID, deleted_quantity, deleted_price)
    VALUES
        (OLD.productID, OLD.productCode, OLD.`name`, OLD.supplierID, OLD.quantity, OLD.price);
END //
DELIMITER ;

DELETE FROM products
WHERE `name` = 'Pencil 2H';

SELECT * FROM deletedProducts;


-- Task 7
DROP TABLE IF EXISTS updatedProducts;

CREATE TABLE updatedProducts(
    updated_productID INT UNSIGNED PRIMARY KEY NOT NULL AUTO_INCREMENT,
    updated_productCode VARCHAR(30) NOT NULL DEFAULT '',
    updated_name VARCHAR(30) NOT NULL DEFAULT '',
    updated_supplierID INT UNSIGNED NOT NULL,
    updated_quantity INT UNSIGNED NOT NULL DEFAULT 0,
    updated_price DECIMAL(7,2) NOT NULL DEFAULT 99999.99,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_supplierID_updated
    FOREIGN KEY (updated_supplierID)
    REFERENCES suppliers(supplierID)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

DROP TRIGGER IF EXISTS after_update;
DELIMITER //
CREATE TRIGGER after_update
AFTER UPDATE
ON products FOR EACH ROW
BEGIN
    INSERT INTO updatedProducts (updated_productID, updated_productCode, updated_name, updated_supplierID, updated_quantity, updated_price)
    VALUES
        (OLD.productID, OLD.productCode, OLD.`name`, OLD.supplierID, OLD.quantity, OLD.price);
END //
DELIMITER ;

UPDATE products
SET productCode = 'KALEM'
WHERE productCode = 'PEN';

SELECT * FROM updatedProducts;