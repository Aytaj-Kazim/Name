create database expressnode;

use expressnode;

create table users(
    id int primary key auto_increment,
    username varchar(30) not null,
    password varchar(100) not null,
    userType enum('admin','user')
);

