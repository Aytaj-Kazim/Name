const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const dotenv = require("dotenv").config();
const bcrypt = require("bcrypt");
const mysql = require("mysql2");
const session = require("express-session");
const cookieParser = require("cookie-parser");

const {body,validationResult} = require("express-validator");

app.use(bodyParser.urlencoded({extended: false}));
app.set('view engine','ejs');
app.use(cookieParser());
app.use(session({
    name: "usersession",
    resave: false,
    saveUninitialized: false,
    secret: process.env.secretkey
}))

var conn = mysql.createConnection({
    host: "localhost",
    user: process.env.user,
    password: process.env.password,
    database: "expressnode"
});

conn.connect((err)=>{
    if (err) throw err;
    console.log("connected to database successfully");
});

var message="";
var valid = "";

app.get("/",(req,res)=>{
    res.render("register",{message: "",valid: ""});
});

app.post("/",
    body("username").trim().escape().isLength({min:5,max:10}).withMessage("Username must be minimum 3, maximum 10 letters")
    .matches("^[A-Za-z]*$").withMessage("Username can only contain letters"),
    body("password").trim().escape().isLength({min: 8}).withMessage("Password must be minimum 8 characters")
    .matches("[A-Z]").withMessage("Password must contain minimum one capital letter")
    .matches("[0-9]").withMessage("Password must contain minimum one digit"),
    body("usertype").not().isEmpty().withMessage("Please enter user type"),
    (req,res)=>{
        var errors = validationResult(req);
        if (!errors.isEmpty()){
            res.render("register",{message: "",valid: errors.array()});
        }
        else{
            if (req.body.password!=req.body.confirmPassword){
                message="Passwords do not match, please enter confirm password correctly"
                res.render("register",{message,valid:""})
            }
            else{
                conn.query("select * from users where username = ?",[req.body.username],(err,result)=>{
                    if (err) throw err;
                    if (result.length){
                        message= "username already exists";
                        res.render("register",{message,valid:""});
                    }
                    else{
                        bcrypt.hash(req.body.password, 10).then((hashedPassword)=>{
                            conn.query("insert into users(username,password,userType) values(?,?,?)",[req.body.username,hashedPassword,req.body.usertype],(err)=>{
                                if (err) throw err;
                                req.session.username = req.body.username;
                                req.session.usertype = req.body.usertype;
                                req.session.loggedin = true;
                                if (req.body.usertype=="admin"){
                                    req.session.cookie = {maxage:1000*60*60*0.1*24*7};
                                }
                                else{
                                    req.session.cookie = {maxage:1000*60*0.1};
                                }
                                res.redirect("/dashboard");
                            });
                        })
                    }

                })
    
            }
        }
    }
)

app.get("/dashboard",(req,res)=>{
    if (req.session.loggedin){
        if (req.session.usertype=="admin"){
            conn.query("select * from users",(err,result)=>{
                if (err) throw err;
                res.render("dashboard",{flag: 1,username: req.session.username,usertype:req.session.usertype,users:result})
            })
        }
        else{
            res.render("dashboard",{flag:0,username:req.session.username});
        }
    }
    else{
        res.redirect("/");
    }
})
app.get("/logout",(req,res)=>{
    req.session.destroy((err)=>{
        if (err) throw err;
        console.log("session successfully destroyed");
        res.redirect("/")
    })
})


app.listen("9000",(err)=>{
    if (err) throw err;
    console.log("server started successfully");
})