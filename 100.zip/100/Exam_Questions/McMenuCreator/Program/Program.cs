﻿using System;
using Classlib;

SpecificMenu McMenu = new SpecificMenu("Mc Menu");

SpecificMenu SmallMenu = new SpecificMenu("Small Menu");
SpecificMenu BigMenu = new SpecificMenu("Big Menu");

McMenu.AddComponent(SmallMenu);
McMenu.AddComponent(BigMenu);

SpecificMenu Burger = new SpecificMenu("Burger");
IMenuComponent Meat = new Ingredients("Meat", 4.75);
IMenuComponent Buns = new Ingredients("Buns", 4.50);
IMenuComponent Cheese = new Ingredients("Cheese", 2.50);

Burger.AddComponent(Meat);
Burger.AddComponent(Buns);
Burger.AddComponent(Cheese);

IMenuComponent Cola = new Ingredients("Cola", 2.80);
IMenuComponent Fries = new Ingredients("Fries", 3.40);

SmallMenu.AddComponent(Cola);
SmallMenu.AddComponent(Fries);
SmallMenu.AddComponent(Burger);

SpecificMenu BigBurger = new SpecificMenu("Big Burger");
BigBurger.AddComponent(Meat);
BigBurger.AddComponent(Meat);
BigBurger.AddComponent(Buns);
BigBurger.AddComponent(Cheese);

IMenuComponent IceCream = new Ingredients("Ice cream", 1.90);
IMenuComponent Nuggets = new Ingredients("Nuggets", 5.25);

BigMenu.AddComponent(IceCream);
BigMenu.AddComponent(Cola);
BigMenu.AddComponent(Nuggets);
BigMenu.AddComponent(BigBurger);

McMenu.Display();
Console.WriteLine("---------------------------------");
Console.WriteLine("Total price for " + SmallMenu.MenuTitle + ": " + SmallMenu.GetPrice());
Console.WriteLine("Total price for " + BigMenu.MenuTitle + ": " + BigMenu.GetPrice());
