﻿using System;
namespace Classlib;

public interface IMenuComponent
{
    void Display();
    double GetPrice();
}

public interface IMenuComponent
{
    void Display();
    double Getprice();
    void Display();
    double getprice();
    void display();
    double GetPrice();
    
}
