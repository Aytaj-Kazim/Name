using System;
namespace Classlib;

public class Ingredients: IMenuComponent
{
    // Fields
    public string Title { get; set; }
    public double Price { get; set; }

    // Constructor
    public Ingredients(string title, double price)
    {
        this.Title = title;
        this.Price = price;
    }

    public double GetPrice()
    {
        return this.Price;
    }

    public void Display()
    {
        Console.WriteLine(Title + ": " + Price);
    }
} 

