using System;
namespace Classlib;

public class SpecificMenu : IMenuComponent
{
    // Fields
    private List<IMenuComponent> MenuElements = new List<IMenuComponent> ();
    public string MenuTitle;

    // Constructor
    public SpecificMenu(string title)
    {
        this.MenuTitle = title;
    } 

    public void AddComponent(IMenuComponent component)
    {
        this.MenuElements.Add(component);
    }

    public void RemoveComponent(IMenuComponent component)
    {
        this.MenuElements.Remove(component);
    }

    public double GetPrice()
    {
        double TotalPrice = 0;

        foreach (var element in this.MenuElements)
        {
            TotalPrice += element.GetPrice();
        }

        return TotalPrice;
    }

    public void Display()
    {
        Console.WriteLine("--------------------");
        Console.WriteLine(this.MenuTitle);
        Console.WriteLine("--------------------");

        foreach (var element in this.MenuElements)
        {
            element.Display();
        }
    }
}