﻿using System;
using Classlib;

ITea tea = new Milk(new Lemon(new Milk(new Tea())));
var status = tea.GetStatus();
var totalPrice = tea.GetTotalPrice();

Console.WriteLine($"Current status: {status}");
Console.WriteLine($"Current price: $ {totalPrice}");


