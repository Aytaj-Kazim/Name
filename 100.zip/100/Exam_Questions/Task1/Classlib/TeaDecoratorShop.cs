﻿namespace Classlib;

public interface ITea
{
    double GetTotalPrice();
    string GetStatus();
}


public class Tea : ITea
{
    public string Title { get; set; }
    public double Price { get; set; }
    
    public string GetStatus()
    {
        this.Title = "Tea ";

        return this.Title;        
    }

    public double GetTotalPrice()
    {
        this.Price = .10;

        return this.Price;
    }
}


public class TeaDecorator : ITea
{
    protected ITea tea;

    public TeaDecorator(ITea tea)
    {
        this.tea = tea;
    }

    public virtual double GetTotalPrice()
    {
        return this.tea.GetTotalPrice();
    }

    public virtual string GetStatus()
    {
        return this.tea.GetStatus();
    }
}


public class Milk : TeaDecorator
{
    public Milk(ITea tea) : base(tea) {}

    public override string GetStatus()
    {
        return tea.GetStatus() + AddStatus();
    }

    public string AddStatus()
    {
        return " with milk";
    }

    public override double GetTotalPrice()
    {
        return tea.GetTotalPrice() + AddPrice();
    }

    public double AddPrice()
    {
        return 2.00;
    }
}


public class Lemon : TeaDecorator
{
    public Lemon(ITea tea) : base(tea) {}

    public override string GetStatus()
    {
        return tea.GetStatus() + AddStatus();
    }

    public string AddStatus()
    {
        return " with lemon";
    }

    public override double GetTotalPrice()
    {
        return tea.GetTotalPrice() + AddPrice();
    }

    public double AddPrice()
    {
        return 1.50;
    }
}


public class Cream : TeaDecorator
{
    public Cream(ITea tea) : base(tea) {}

    public override string GetStatus()
    {
        return tea.GetStatus() + AddStatus();
    }

    public string AddStatus()
    {
        return " with cream";
    }

    public override double GetTotalPrice()
    {
        return tea.GetTotalPrice() + AddPrice();
    }

    public double AddPrice()
    {
        return 1.80;
    }
}


public class Sugar : TeaDecorator
{
    public Sugar(ITea tea) : base(tea) {}

    public override string GetStatus()
    {
        return tea.GetStatus() + AddStatus();
    }

    public string AddStatus()
    {
        return " with sugar";
    }

    public override double GetTotalPrice()
    {
        return tea.GetTotalPrice() + AddPrice();
    }

    public double AddPrice()
    {
        return 0.80;
    }
}