﻿using System;
using Classlib;

Calculator c = Calculator.Init();
var res = c.Add(2).Multiply(3).GetResult();

Console.WriteLine($"\nResult: {res}");

Calculator c2 = Calculator.Init();
res = c2.Add(2).GetResult();

Console.WriteLine($"\nResult: {res}");
