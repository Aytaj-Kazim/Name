﻿using System;

namespace Classlib;

public class Calculator
{
    private static Calculator _instance;
    private int _value;

    public static Calculator Init()
    {
        if (_instance == null)
        {
            _instance = new Calculator();
            _instance._value = 0;
        }

        return _instance;
    }

    public Calculator Add(int n)
    {
        _instance._value += n;

        return _instance;
    }

    public Calculator Subtract(int n)
    {
        _instance._value -= n;

        return _instance;
    }

    public Calculator Power(int n)
    {
        _instance._value = (int)Math.Pow(_instance._value, n);

        return _instance;
    }

    public Calculator Multiply(int n)
    {
        _instance._value *= n;

        return _instance;
    }

    public Calculator Divide(int n)
    {
        _instance._value /= n;

        return _instance;
    }

    public int GetResult()
    {
        return _instance._value;
    }
}
