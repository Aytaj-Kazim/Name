Python code to connect and send commands to a MikroTik router via SSH
